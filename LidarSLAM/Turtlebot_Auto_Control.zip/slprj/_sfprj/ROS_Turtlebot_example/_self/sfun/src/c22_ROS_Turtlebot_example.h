#ifndef __c22_ROS_Turtlebot_example_h__
#define __c22_ROS_Turtlebot_example_h__

/* Forward Declarations */
#ifndef typedef_c22_quaternion
#define typedef_c22_quaternion

typedef struct c22_tag_ETUVMFbswjPoNMVxiAsnq c22_quaternion;

#endif                                 /* typedef_c22_quaternion */

#ifndef typedef_c22_s_FDrX8kOEjZXLXru8nW4swE
#define typedef_c22_s_FDrX8kOEjZXLXru8nW4swE

typedef struct c22_tag_FDrX8kOEjZXLXru8nW4swE c22_s_FDrX8kOEjZXLXru8nW4swE;

#endif                                 /* typedef_c22_s_FDrX8kOEjZXLXru8nW4swE */

#ifndef typedef_c22_cell_1
#define typedef_c22_cell_1

typedef struct c22_tag_YcHb181yZEiUj1RqSxvRvH c22_cell_1;

#endif                                 /* typedef_c22_cell_1 */

#ifndef typedef_c22_s_w3m1Q26ivrDTAtgc0mcqVE
#define typedef_c22_s_w3m1Q26ivrDTAtgc0mcqVE

typedef struct c22_tag_w3m1Q26ivrDTAtgc0mcqVE c22_s_w3m1Q26ivrDTAtgc0mcqVE;

#endif                                 /* typedef_c22_s_w3m1Q26ivrDTAtgc0mcqVE */

#ifndef typedef_c22_s_bMCO6Q5oJM4qv2raxx5j2
#define typedef_c22_s_bMCO6Q5oJM4qv2raxx5j2

typedef struct c22_tag_bMCO6Q5oJM4qv2raxx5j2 c22_s_bMCO6Q5oJM4qv2raxx5j2;

#endif                                 /* typedef_c22_s_bMCO6Q5oJM4qv2raxx5j2 */

struct SFc22_ROS_Turtlebot_exampleInstanceStruct;

/* Type Definitions */
#ifndef struct_c22_tag_ETUVMFbswjPoNMVxiAsnq
#define struct_c22_tag_ETUVMFbswjPoNMVxiAsnq

struct c22_tag_ETUVMFbswjPoNMVxiAsnq
{
  real_T a;
  real_T b;
  real_T c;
  real_T d;
};

#endif                                 /* struct_c22_tag_ETUVMFbswjPoNMVxiAsnq */

#ifndef typedef_c22_quaternion
#define typedef_c22_quaternion

typedef c22_tag_ETUVMFbswjPoNMVxiAsnq c22_quaternion;

#endif                                 /* typedef_c22_quaternion */

#ifndef struct_c22_tag_FDrX8kOEjZXLXru8nW4swE
#define struct_c22_tag_FDrX8kOEjZXLXru8nW4swE

struct c22_tag_FDrX8kOEjZXLXru8nW4swE
{
  char_T f1[6];
  char_T f2[6];
};

#endif                                 /* struct_c22_tag_FDrX8kOEjZXLXru8nW4swE */

#ifndef typedef_c22_s_FDrX8kOEjZXLXru8nW4swE
#define typedef_c22_s_FDrX8kOEjZXLXru8nW4swE

typedef c22_tag_FDrX8kOEjZXLXru8nW4swE c22_s_FDrX8kOEjZXLXru8nW4swE;

#endif                                 /* typedef_c22_s_FDrX8kOEjZXLXru8nW4swE */

#ifndef struct_c22_tag_YcHb181yZEiUj1RqSxvRvH
#define struct_c22_tag_YcHb181yZEiUj1RqSxvRvH

struct c22_tag_YcHb181yZEiUj1RqSxvRvH
{
  char_T f1[4];
  char_T f2[2];
  char_T f3[5];
  real_T f4;
};

#endif                                 /* struct_c22_tag_YcHb181yZEiUj1RqSxvRvH */

#ifndef typedef_c22_cell_1
#define typedef_c22_cell_1

typedef c22_tag_YcHb181yZEiUj1RqSxvRvH c22_cell_1;

#endif                                 /* typedef_c22_cell_1 */

#ifndef struct_c22_tag_w3m1Q26ivrDTAtgc0mcqVE
#define struct_c22_tag_w3m1Q26ivrDTAtgc0mcqVE

struct c22_tag_w3m1Q26ivrDTAtgc0mcqVE
{
  c22_s_FDrX8kOEjZXLXru8nW4swE _data;
};

#endif                                 /* struct_c22_tag_w3m1Q26ivrDTAtgc0mcqVE */

#ifndef typedef_c22_s_w3m1Q26ivrDTAtgc0mcqVE
#define typedef_c22_s_w3m1Q26ivrDTAtgc0mcqVE

typedef c22_tag_w3m1Q26ivrDTAtgc0mcqVE c22_s_w3m1Q26ivrDTAtgc0mcqVE;

#endif                                 /* typedef_c22_s_w3m1Q26ivrDTAtgc0mcqVE */

#ifndef struct_c22_tag_bMCO6Q5oJM4qv2raxx5j2
#define struct_c22_tag_bMCO6Q5oJM4qv2raxx5j2

struct c22_tag_bMCO6Q5oJM4qv2raxx5j2
{
  c22_cell_1 _data;
};

#endif                                 /* struct_c22_tag_bMCO6Q5oJM4qv2raxx5j2 */

#ifndef typedef_c22_s_bMCO6Q5oJM4qv2raxx5j2
#define typedef_c22_s_bMCO6Q5oJM4qv2raxx5j2

typedef c22_tag_bMCO6Q5oJM4qv2raxx5j2 c22_s_bMCO6Q5oJM4qv2raxx5j2;

#endif                                 /* typedef_c22_s_bMCO6Q5oJM4qv2raxx5j2 */

#ifndef typedef_c22_ROS_Turtlebot_exampleStackData
#define typedef_c22_ROS_Turtlebot_exampleStackData

typedef struct {
} c22_ROS_Turtlebot_exampleStackData;

#endif                                 /* typedef_c22_ROS_Turtlebot_exampleStackData */

#ifndef struct_SFc22_ROS_Turtlebot_exampleInstanceStruct
#define struct_SFc22_ROS_Turtlebot_exampleInstanceStruct

struct SFc22_ROS_Turtlebot_exampleInstanceStruct
{
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c22_sfEvent;
  boolean_T c22_doneDoubleBufferReInit;
  uint8_T c22_is_active_c22_ROS_Turtlebot_example;
  uint8_T c22_JITStateAnimation[1];
  uint8_T c22_JITTransitionAnimation[1];
  int32_T c22_IsDebuggerActive;
  int32_T c22_IsSequenceViewerPresent;
  int32_T c22_SequenceViewerOptimization;
  int32_T c22_IsHeatMapPresent;
  void *c22_RuntimeVar;
  uint32_T c22_mlFcnLineNumber;
  void *c22_fcnDataPtrs[3];
  char_T *c22_dataNames[3];
  uint32_T c22_numFcnVars;
  uint32_T c22_ssIds[3];
  uint32_T c22_statuses[3];
  void *c22_outMexFcns[3];
  void *c22_inMexFcns[3];
  CovrtStateflowInstance *c22_covrtInstance;
  void *c22_fEmlrtCtx;
  real_T (*c22_u)[4];
  real_T *c22_y;
  real_T (*c22_v)[4];
};

#endif                                 /* struct_SFc22_ROS_Turtlebot_exampleInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c22_ROS_Turtlebot_example_get_eml_resolved_functions_info();

/* Function Definitions */
extern void sf_c22_ROS_Turtlebot_example_get_check_sum(mxArray *plhs[]);
extern void c22_ROS_Turtlebot_example_method_dispatcher(SimStruct *S, int_T
  method, void *data);

#endif
