/* Include files */

#include "ROS_Turtlebot_example_sfun.h"
#include "c22_ROS_Turtlebot_example.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
const int32_T CALL_EVENT = -1;

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtMCInfo c22_emlrtMCI = { 13,/* lineNo */
  9,                                   /* colNo */
  "sqrt",                              /* fName */
  "/usr/local/MATLAB/R2023a/toolbox/eml/lib/matlab/elfun/sqrt.m"/* pName */
};

static emlrtMCInfo c22_b_emlrtMCI = { 14,/* lineNo */
  9,                                   /* colNo */
  "acos",                              /* fName */
  "/usr/local/MATLAB/R2023a/toolbox/eml/lib/matlab/elfun/acos.m"/* pName */
};

static emlrtRSInfo c22_emlrtRSI = { 21,/* lineNo */
  "dist",                              /* fcnName */
  "/usr/local/MATLAB/R2023a/toolbox/shared/rotations/rotationslib/+matlabshared/+rotations/+internal/+coder/@quaternioncg/dist.m"/* pathName */
};

static emlrtRSInfo c22_b_emlrtRSI = { 29,/* lineNo */
  "dist",                              /* fcnName */
  "/usr/local/MATLAB/R2023a/toolbox/shared/rotations/rotationslib/+matlabshared/+rotations/+internal/+coder/@quaternioncg/dist.m"/* pathName */
};

static emlrtRSInfo c22_c_emlrtRSI = { 10,/* lineNo */
  "normalize",                         /* fcnName */
  "/usr/local/MATLAB/R2023a/toolbox/shared/rotations/rotationslib/+matlabshared/+rotations/+internal/@quaternionBase/normalize.m"/* pathName */
};

static emlrtRSInfo c22_d_emlrtRSI = { 6,/* lineNo */
  "Enabled Subsystem1/MATLAB Function4",/* fcnName */
  "#ROS_Turtlebot_example:184"         /* pathName */
};

static emlrtRTEInfo c22_emlrtRTEI = { 27,/* lineNo */
  18,                                  /* colNo */
  "dist",                              /* fName */
  "/usr/local/MATLAB/R2023a/toolbox/shared/rotations/rotationslib/+matlabshared/+rotations/+internal/+coder/@quaternioncg/dist.m"/* pName */
};

static emlrtECInfo c22_emlrtECI = { -1,/* nDims */
  27,                                  /* lineNo */
  5,                                   /* colNo */
  "dist",                              /* fName */
  "/usr/local/MATLAB/R2023a/toolbox/shared/rotations/rotationslib/+matlabshared/+rotations/+internal/+coder/@quaternioncg/dist.m"/* pName */
};

/* Function Declarations */
static void initialize_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void initialize_params_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void mdl_start_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void mdl_terminate_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void enable_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void disable_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void sf_gateway_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void ext_mode_exec_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void c22_update_jit_animation_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void c22_do_animation_call_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void set_sim_state_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance, const mxArray
   *c22_st);
static void initSimStructsc22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void initSubchartIOPointersc22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static real_T c22_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance, const mxArray *c22_b_y, const char_T *c22_identifier);
static real_T c22_b_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance, const mxArray *c22_b_u, const emlrtMsgIdentifier *c22_parentId);
static uint8_T c22_c_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct *
  chartInstance, const mxArray *c22_b_is_active_c22_ROS_Turtlebot_example, const
  char_T *c22_identifier);
static uint8_T c22_d_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct *
  chartInstance, const mxArray *c22_b_u, const emlrtMsgIdentifier *c22_parentId);
static void c22_slStringInitializeDynamicBuffers
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance);
static void c22_chart_data_browse_helper
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance, int32_T
   c22_ssIdNumber, const mxArray **c22_mxData, uint8_T *c22_isValueTooBig);
static void init_dsm_address_info(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
  chartInstance->c22_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c22_is_active_c22_ROS_Turtlebot_example = 0U;
}

static void initialize_params_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

static void mdl_start_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
}

static void mdl_terminate_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

static void mdl_setup_runtime_resources_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  static const uint32_T c22_decisionTxtEndIdx = 0U;
  static const uint32_T c22_decisionTxtStartIdx = 0U;
  setDebuggerFlag(chartInstance->S, true);
  setDataBrowseFcn(chartInstance->S, (void *)&c22_chart_data_browse_helper);
  chartInstance->c22_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c22_RuntimeVar,
    &chartInstance->c22_IsDebuggerActive,
    &chartInstance->c22_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c22_mlFcnLineNumber, &chartInstance->c22_IsHeatMapPresent, 0);
  covrtCreateStateflowInstanceData(chartInstance->c22_covrtInstance, 1U, 0U, 1U,
    26U);
  covrtChartInitFcn(chartInstance->c22_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c22_covrtInstance, 0U, 0U, false, false,
                    false, 0U, &c22_decisionTxtStartIdx, &c22_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c22_covrtInstance, 0U, 0, NULL, NULL, 0U,
                    NULL);
  covrtEmlInitFcn(chartInstance->c22_covrtInstance, "", 4U, 0U, 1U, 0U, 0U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c22_covrtInstance, 4U, 0U, 0U,
                     "eML_blk_kernel", 0, -1, 189);
}

static void mdl_cleanup_runtime_resources_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c22_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c22_covrtInstance);
}

static void enable_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void sf_gateway_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  static char_T c22_cv[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  static char_T c22_cv2[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  static char_T c22_cv1[4] = { 's', 'q', 'r', 't' };

  static char_T c22_cv3[4] = { 'a', 'c', 'o', 's' };

  c22_quaternion c22_deltaQuat;
  c22_quaternion c22_obj;
  emlrtStack c22_b_st;
  emlrtStack c22_c_st;
  emlrtStack c22_d_st;
  emlrtStack c22_st = { NULL,          /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  const mxArray *c22_b_y = NULL;
  const mxArray *c22_c_y = NULL;
  const mxArray *c22_d_y = NULL;
  const mxArray *c22_f_y = NULL;
  const mxArray *c22_g_y = NULL;
  const mxArray *c22_i_y = NULL;
  real_T c22_b_tmp_data[1];
  real_T c22_dv[1];
  real_T c22_angleInRadians;
  real_T c22_arg1;
  real_T c22_arg2;
  real_T c22_arg3;
  real_T c22_arg4;
  real_T c22_b_arg1;
  real_T c22_b_arg2;
  real_T c22_b_arg3;
  real_T c22_b_arg4;
  real_T c22_b_x;
  real_T c22_c_arg1;
  real_T c22_c_arg2;
  real_T c22_c_arg3;
  real_T c22_c_arg4;
  real_T c22_e_x;
  real_T c22_f_x;
  real_T c22_g_x;
  real_T c22_h_x;
  real_T c22_h_y;
  real_T c22_n;
  real_T c22_oa;
  real_T c22_ob;
  real_T c22_oc;
  real_T c22_od;
  real_T c22_rpart;
  real_T c22_varargin_1;
  real_T c22_varargin_2;
  real_T c22_varargin_3;
  real_T c22_varargin_4;
  real_T c22_x;
  real_T c22_xa;
  real_T c22_xb;
  real_T c22_xc;
  real_T c22_xd;
  real_T c22_ya;
  real_T c22_yb;
  real_T c22_yc;
  real_T c22_yd;
  int32_T c22_b_tmp_size[2];
  int32_T c22_iv[2];
  int32_T c22_iv1[2];
  int32_T c22_iv2[2];
  int32_T c22_tmp_size[2];
  int32_T c22_tmp_data[1];
  int32_T c22_b_end;
  int32_T c22_b_i;
  int32_T c22_b_loop_ub;
  int32_T c22_b_trueCount;
  int32_T c22_c_end;
  int32_T c22_c_i;
  int32_T c22_c_trueCount;
  int32_T c22_d_i;
  int32_T c22_e_i;
  int32_T c22_end;
  int32_T c22_i;
  int32_T c22_i1;
  int32_T c22_i2;
  int32_T c22_i3;
  int32_T c22_loop_ub;
  int32_T c22_partialTrueCount;
  int32_T c22_trueCount;
  boolean_T c22_b;
  boolean_T c22_b2;
  boolean_T c22_b_b1;
  boolean_T c22_b_p;
  boolean_T c22_c_p;
  boolean_T c22_c_x;
  boolean_T c22_d_p;
  boolean_T c22_d_x;
  boolean_T c22_e_y;
  boolean_T c22_p;
  c22_st.tls = chartInstance->c22_fEmlrtCtx;
  c22_b_st.prev = &c22_st;
  c22_b_st.tls = c22_st.tls;
  c22_c_st.prev = &c22_b_st;
  c22_c_st.tls = c22_b_st.tls;
  c22_d_st.prev = &c22_c_st;
  c22_d_st.tls = c22_c_st.tls;
  chartInstance->c22_JITTransitionAnimation[0] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  for (c22_i = 0; c22_i < 4; c22_i++) {
    covrtSigUpdateFcn(chartInstance->c22_covrtInstance, 1U,
                      (*chartInstance->c22_v)[c22_i]);
  }

  for (c22_i1 = 0; c22_i1 < 4; c22_i1++) {
    covrtSigUpdateFcn(chartInstance->c22_covrtInstance, 0U,
                      (*chartInstance->c22_u)[c22_i1]);
  }

  chartInstance->c22_sfEvent = CALL_EVENT;
  covrtEmlFcnEval(chartInstance->c22_covrtInstance, 4U, 0, 0);
  c22_deltaQuat.a = (*chartInstance->c22_u)[0];
  c22_deltaQuat.b = (*chartInstance->c22_u)[1];
  c22_deltaQuat.c = (*chartInstance->c22_u)[2];
  c22_deltaQuat.d = (*chartInstance->c22_u)[3];
  c22_obj.a = (*chartInstance->c22_v)[0];
  c22_obj.b = (*chartInstance->c22_v)[1];
  c22_obj.c = (*chartInstance->c22_v)[2];
  c22_obj.d = (*chartInstance->c22_v)[3];
  c22_b_st.site = &c22_d_emlrtRSI;
  c22_obj.b = -c22_obj.b;
  c22_obj.c = -c22_obj.c;
  c22_obj.d = -c22_obj.d;
  c22_xa = c22_deltaQuat.a;
  c22_xb = c22_deltaQuat.b;
  c22_xc = c22_deltaQuat.c;
  c22_xd = c22_deltaQuat.d;
  c22_ya = c22_obj.a;
  c22_yb = c22_obj.b;
  c22_yc = c22_obj.c;
  c22_yd = c22_obj.d;
  c22_oa = ((c22_xa * c22_ya - c22_xb * c22_yb) - c22_xc * c22_yc) - c22_xd *
    c22_yd;
  c22_ob = ((c22_xa * c22_yb + c22_xb * c22_ya) + c22_xc * c22_yd) - c22_xd *
    c22_yc;
  c22_oc = ((c22_xa * c22_yc - c22_xb * c22_yd) + c22_xc * c22_ya) + c22_xd *
    c22_yb;
  c22_od = ((c22_xa * c22_yd + c22_xb * c22_yc) - c22_xc * c22_yb) + c22_xd *
    c22_ya;
  c22_varargin_1 = c22_oa;
  c22_varargin_2 = c22_ob;
  c22_varargin_3 = c22_oc;
  c22_varargin_4 = c22_od;
  c22_arg1 = c22_varargin_1;
  c22_arg2 = c22_varargin_2;
  c22_arg3 = c22_varargin_3;
  c22_arg4 = c22_varargin_4;
  c22_b_arg1 = c22_arg1;
  c22_b_arg2 = c22_arg2;
  c22_b_arg3 = c22_arg3;
  c22_b_arg4 = c22_arg4;
  c22_c_arg4 = c22_b_arg4;
  c22_c_arg3 = c22_b_arg3;
  c22_c_arg2 = c22_b_arg2;
  c22_c_arg1 = c22_b_arg1;
  c22_deltaQuat.a = c22_c_arg1;
  c22_deltaQuat.b = c22_c_arg2;
  c22_deltaQuat.c = c22_c_arg3;
  c22_deltaQuat.d = c22_c_arg4;
  c22_c_st.site = &c22_emlrtRSI;
  c22_d_st.site = &c22_c_emlrtRSI;
  c22_x = ((c22_deltaQuat.a * c22_deltaQuat.a + c22_deltaQuat.b *
            c22_deltaQuat.b) + c22_deltaQuat.c * c22_deltaQuat.c) +
    c22_deltaQuat.d * c22_deltaQuat.d;
  c22_n = c22_x;
  c22_b_x = c22_n;
  if (c22_b_x < 0.0) {
    c22_p = true;
  } else {
    c22_p = false;
  }

  c22_b_p = c22_p;
  if (c22_b_p) {
    c22_b_y = NULL;
    sf_mex_assign(&c22_b_y, sf_mex_create("y", c22_cv, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    c22_c_y = NULL;
    sf_mex_assign(&c22_c_y, sf_mex_create("y", c22_cv, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    c22_d_y = NULL;
    sf_mex_assign(&c22_d_y, sf_mex_create("y", c22_cv1, 10, 0U, 1U, 0U, 2, 1, 4),
                  false);
    sf_mex_call(&c22_d_st, &c22_emlrtMCI, "error", 0U, 2U, 14, c22_b_y, 14,
                sf_mex_call(&c22_d_st, NULL, "getString", 1U, 1U, 14,
      sf_mex_call(&c22_d_st, NULL, "message", 1U, 2U, 14, c22_c_y, 14, c22_d_y)));
  }

  c22_n = muDoubleScalarSqrt(c22_n);
  c22_deltaQuat.a /= c22_n;
  c22_rpart = c22_deltaQuat.a;
  c22_c_x = (c22_rpart < 0.0);
  c22_d_x = c22_c_x;
  if (!c22_d_x) {
    c22_b = true;
  } else {
    c22_b = false;
  }

  c22_e_y = !c22_b;
  if (c22_e_y) {
    c22_end = 1;
    c22_trueCount = 0;
    for (c22_b_i = 0; c22_b_i < c22_end; c22_b_i++) {
      if (c22_rpart < 0.0) {
        c22_trueCount++;
      }
    }

    c22_tmp_size[1] = c22_trueCount;
    c22_partialTrueCount = 0;
    for (c22_c_i = 0; c22_c_i < c22_end; c22_c_i++) {
      if (c22_rpart < 0.0) {
        c22_tmp_data[c22_partialTrueCount] = c22_c_i;
        c22_partialTrueCount++;
      }
    }

    c22_b_end = 1;
    c22_b_trueCount = 0;
    for (c22_d_i = 0; c22_d_i < c22_b_end; c22_d_i++) {
      if (c22_rpart < 0.0) {
        c22_b_trueCount++;
      }
    }

    c22_iv[1] = c22_b_trueCount;
    c22_b_tmp_size[1] = c22_iv[1];
    c22_c_end = 1;
    c22_c_trueCount = 0;
    for (c22_e_i = 0; c22_e_i < c22_c_end; c22_e_i++) {
      if (c22_rpart < 0.0) {
        c22_c_trueCount++;
      }
    }

    c22_iv1[0] = 1;
    c22_iv2[1] = c22_c_trueCount;
    c22_loop_ub = c22_iv1[0] * c22_iv2[1] - 1;
    for (c22_i2 = 0; c22_i2 <= c22_loop_ub; c22_i2++) {
      c22_b_tmp_data[c22_i2] = -c22_rpart;
    }

    if (c22_tmp_size[1] != c22_b_tmp_size[1]) {
      emlrtSubAssignSizeCheck1dR2017a(c22_tmp_size[1], c22_b_tmp_size[1],
        &c22_emlrtECI, &c22_b_st);
    }

    c22_dv[0] = c22_rpart;
    c22_b_loop_ub = c22_b_tmp_size[1] - 1;
    for (c22_i3 = 0; c22_i3 <= c22_b_loop_ub; c22_i3++) {
      c22_dv[c22_tmp_data[c22_i3]] = c22_b_tmp_data[c22_i3];
    }

    c22_rpart = c22_dv[0];
  }

  c22_c_st.site = &c22_b_emlrtRSI;
  c22_e_x = c22_rpart;
  c22_f_x = c22_e_x;
  c22_g_x = c22_f_x;
  c22_b_b1 = (c22_g_x < -1.0);
  c22_b2 = (c22_g_x > 1.0);
  if (c22_b_b1 || c22_b2) {
    c22_c_p = true;
  } else {
    c22_c_p = false;
  }

  c22_d_p = c22_c_p;
  if (c22_d_p) {
    c22_f_y = NULL;
    sf_mex_assign(&c22_f_y, sf_mex_create("y", c22_cv2, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    c22_g_y = NULL;
    sf_mex_assign(&c22_g_y, sf_mex_create("y", c22_cv2, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    c22_i_y = NULL;
    sf_mex_assign(&c22_i_y, sf_mex_create("y", c22_cv3, 10, 0U, 1U, 0U, 2, 1, 4),
                  false);
    sf_mex_call(&c22_c_st, &c22_b_emlrtMCI, "error", 0U, 2U, 14, c22_f_y, 14,
                sf_mex_call(&c22_c_st, NULL, "getString", 1U, 1U, 14,
      sf_mex_call(&c22_c_st, NULL, "message", 1U, 2U, 14, c22_g_y, 14, c22_i_y)));
  }

  c22_f_x = muDoubleScalarAcos(c22_f_x);
  c22_h_x = 2.0 * c22_f_x;
  c22_angleInRadians = c22_h_x;
  c22_h_y = 57.295779513082323 * c22_angleInRadians;
  *chartInstance->c22_y = c22_h_y;
  c22_do_animation_call_c22_ROS_Turtlebot_example(chartInstance);
  covrtSigUpdateFcn(chartInstance->c22_covrtInstance, 2U, *chartInstance->c22_y);
}

static void ext_mode_exec_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

static void c22_update_jit_animation_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

static void c22_do_animation_call_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static const mxArray *get_sim_state_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
  const mxArray *c22_b_y = NULL;
  const mxArray *c22_c_y = NULL;
  const mxArray *c22_d_y = NULL;
  const mxArray *c22_st;
  c22_st = NULL;
  c22_st = NULL;
  c22_b_y = NULL;
  sf_mex_assign(&c22_b_y, sf_mex_createcellmatrix(2, 1), false);
  c22_c_y = NULL;
  sf_mex_assign(&c22_c_y, sf_mex_create("y", chartInstance->c22_y, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c22_b_y, 0, c22_c_y);
  c22_d_y = NULL;
  sf_mex_assign(&c22_d_y, sf_mex_create("y",
    &chartInstance->c22_is_active_c22_ROS_Turtlebot_example, 3, 0U, 0U, 0U, 0),
                false);
  sf_mex_setcell(c22_b_y, 1, c22_d_y);
  sf_mex_assign(&c22_st, c22_b_y, false);
  return c22_st;
}

static void set_sim_state_c22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance, const mxArray
   *c22_st)
{
  const mxArray *c22_b_u;
  chartInstance->c22_doneDoubleBufferReInit = true;
  c22_b_u = sf_mex_dup(c22_st);
  *chartInstance->c22_y = c22_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c22_b_u, 0)), "y");
  chartInstance->c22_is_active_c22_ROS_Turtlebot_example =
    c22_c_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c22_b_u, 1)),
    "is_active_c22_ROS_Turtlebot_example");
  sf_mex_destroy(&c22_b_u);
  sf_mex_destroy(&c22_st);
}

static void initSimStructsc22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

static void initSubchartIOPointersc22_ROS_Turtlebot_example
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

const mxArray *sf_c22_ROS_Turtlebot_example_get_eml_resolved_functions_info()
{
  const mxArray *c22_nameCaptureInfo = NULL;
  c22_nameCaptureInfo = NULL;
  sf_mex_assign(&c22_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c22_nameCaptureInfo;
}

static real_T c22_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance, const mxArray *c22_b_y, const char_T *c22_identifier)
{
  emlrtMsgIdentifier c22_thisId;
  real_T c22_c_y;
  c22_thisId.fIdentifier = const_cast<const char_T *>(c22_identifier);
  c22_thisId.fParent = NULL;
  c22_thisId.bParentIsCell = false;
  c22_c_y = c22_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c22_b_y),
    &c22_thisId);
  sf_mex_destroy(&c22_b_y);
  return c22_c_y;
}

static real_T c22_b_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance, const mxArray *c22_b_u, const emlrtMsgIdentifier *c22_parentId)
{
  real_T c22_b_y;
  real_T c22_d;
  sf_mex_import(c22_parentId, sf_mex_dup(c22_b_u), &c22_d, 1, 0, 0U, 0, 0U, 0);
  c22_b_y = c22_d;
  sf_mex_destroy(&c22_b_u);
  return c22_b_y;
}

static uint8_T c22_c_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct *
  chartInstance, const mxArray *c22_b_is_active_c22_ROS_Turtlebot_example, const
  char_T *c22_identifier)
{
  emlrtMsgIdentifier c22_thisId;
  uint8_T c22_b_y;
  c22_thisId.fIdentifier = const_cast<const char_T *>(c22_identifier);
  c22_thisId.fParent = NULL;
  c22_thisId.bParentIsCell = false;
  c22_b_y = c22_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c22_b_is_active_c22_ROS_Turtlebot_example), &c22_thisId);
  sf_mex_destroy(&c22_b_is_active_c22_ROS_Turtlebot_example);
  return c22_b_y;
}

static uint8_T c22_d_emlrt_marshallIn(SFc22_ROS_Turtlebot_exampleInstanceStruct *
  chartInstance, const mxArray *c22_b_u, const emlrtMsgIdentifier *c22_parentId)
{
  uint8_T c22_b_y;
  uint8_T c22_c_u;
  sf_mex_import(c22_parentId, sf_mex_dup(c22_b_u), &c22_c_u, 1, 3, 0U, 0, 0U, 0);
  c22_b_y = c22_c_u;
  sf_mex_destroy(&c22_b_u);
  return c22_b_y;
}

static void c22_slStringInitializeDynamicBuffers
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance)
{
}

static void c22_chart_data_browse_helper
  (SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance, int32_T
   c22_ssIdNumber, const mxArray **c22_mxData, uint8_T *c22_isValueTooBig)
{
  real_T c22_d;
  *c22_mxData = NULL;
  *c22_mxData = NULL;
  *c22_isValueTooBig = 0U;
  switch (c22_ssIdNumber) {
   case 4U:
    sf_mex_assign(c22_mxData, sf_mex_create("mxData", *chartInstance->c22_u, 0,
      0U, 1U, 0U, 2, 1, 4), false);
    break;

   case 5U:
    c22_d = *chartInstance->c22_y;
    sf_mex_assign(c22_mxData, sf_mex_create("mxData", &c22_d, 0, 0U, 0U, 0U, 0),
                  false);
    break;

   case 6U:
    sf_mex_assign(c22_mxData, sf_mex_create("mxData", *chartInstance->c22_v, 0,
      0U, 1U, 0U, 2, 1, 4), false);
    break;
  }
}

static void init_dsm_address_info(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance)
{
}

static void init_simulink_io_address(SFc22_ROS_Turtlebot_exampleInstanceStruct
  *chartInstance)
{
  chartInstance->c22_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c22_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c22_u = (real_T (*)[4])ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c22_y = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c22_v = (real_T (*)[4])ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c22_ROS_Turtlebot_example_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2083967606U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(392593024U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2228625528U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1404450433U);
}

mxArray *sf_c22_ROS_Turtlebot_example_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c22_ROS_Turtlebot_example_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_vars");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c22_ROS_Turtlebot_example_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c22_ROS_Turtlebot_example(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPhDBxMDABqQ4IEwwYIXyGaFijHBxFri4AhCXVBakgsSLi5I9U4B0XmIumJ9YWuG"
    "Zl5YPNt+CAWE+GxbzGZHM54SKQ8AHe8r0iziA9Bsg6WchoF8AyKqEhQuUJt9+BQfK9EPsjyDgfm"
    "UU90P4mcXxicklmWWp8clGRvFB/sHxIaVFJTmpSfkl8akVibkFOalw80EAAF8CHH4="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c22_ROS_Turtlebot_example_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sItvWt8FEUKUXeAEIcMO8pF";
}

static void sf_opaque_initialize_c22_ROS_Turtlebot_example(void
  *chartInstanceVar)
{
  initialize_params_c22_ROS_Turtlebot_example
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct*) chartInstanceVar);
  initialize_c22_ROS_Turtlebot_example
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c22_ROS_Turtlebot_example(void *chartInstanceVar)
{
  enable_c22_ROS_Turtlebot_example((SFc22_ROS_Turtlebot_exampleInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c22_ROS_Turtlebot_example(void *chartInstanceVar)
{
  disable_c22_ROS_Turtlebot_example((SFc22_ROS_Turtlebot_exampleInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c22_ROS_Turtlebot_example(void *chartInstanceVar)
{
  sf_gateway_c22_ROS_Turtlebot_example
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c22_ROS_Turtlebot_example
  (SimStruct* S)
{
  return get_sim_state_c22_ROS_Turtlebot_example
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct *)sf_get_chart_instance_ptr(S));/* raw sim ctx */
}

static void sf_opaque_set_sim_state_c22_ROS_Turtlebot_example(SimStruct* S,
  const mxArray *st)
{
  set_sim_state_c22_ROS_Turtlebot_example
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct*)sf_get_chart_instance_ptr(S),
     st);
}

static void sf_opaque_cleanup_runtime_resources_c22_ROS_Turtlebot_example(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc22_ROS_Turtlebot_exampleInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_ROS_Turtlebot_example_optimization_info();
    }

    mdl_cleanup_runtime_resources_c22_ROS_Turtlebot_example
      ((SFc22_ROS_Turtlebot_exampleInstanceStruct*) chartInstanceVar);
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct*) chartInstanceVar)->
      ~SFc22_ROS_Turtlebot_exampleInstanceStruct();
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c22_ROS_Turtlebot_example(void *chartInstanceVar)
{
  mdl_start_c22_ROS_Turtlebot_example((SFc22_ROS_Turtlebot_exampleInstanceStruct*)
    chartInstanceVar);
  if (chartInstanceVar) {
    sf_reset_warnings_ChartRunTimeInfo
      (((SFc22_ROS_Turtlebot_exampleInstanceStruct*)chartInstanceVar)->S);
  }
}

static void sf_opaque_mdl_terminate_c22_ROS_Turtlebot_example(void
  *chartInstanceVar)
{
  mdl_terminate_c22_ROS_Turtlebot_example
    ((SFc22_ROS_Turtlebot_exampleInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c22_ROS_Turtlebot_example(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c22_ROS_Turtlebot_example
      ((SFc22_ROS_Turtlebot_exampleInstanceStruct*)sf_get_chart_instance_ptr(S));
    initSubchartIOPointersc22_ROS_Turtlebot_example
      ((SFc22_ROS_Turtlebot_exampleInstanceStruct*)sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c22_ROS_Turtlebot_example_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [22] = {
    "eNrtWN2O20QUdqLtiqqw2gskVKkSlXqDhJBQudkLRHc3PzRiQ6I62VbcRBP7JB5lPOPOTzYpPAi",
    "vwBV9AB4E8QJIXCFxwyVnbCcbvCHxJBRahFdeZ2x/851z5vyNvUqr7eFxhOe3dz3vEK9v4Vn1su",
    "NWPq6snNn9A+/TfPzNHc8LRAhj4L4ZjejMczu4ibtEklh57gcnMTwBJZjRVPAWH4nyWMpHIIEHO",
    "EEipHbiVTQ2jPJJ0/DAMqunEQ0iPxKGhec4IQk7nM3/ijcxuouMdSoh0E2AUEdSmHHUZGS82QpS",
    "X9UiCCbKxM62UqB9k1hVVdswTRMGjRkELa40QSuoLfr6mmio6Zmbka2+yl+gRZwwSnh5W0dE+ZC",
    "gd2joJyH+7xiN1iuFDSIi9TlEZArqgk5SdsGhFDtV+PaQcqKFpIQ1Ylazs5XUt8tQxzaGBHNdI9",
    "T3XAKZJIJy7RgQfhPt3OBkyKAOQzN25PXhubHRcEnhCqTb+o5qYgqSjKHD3WRO16gxS51yGUsls",
    "ZrGcEnkWYC+qyB0yxsYdMon6I7Qw2mcsJCauKV6kk7RN1xzXcuG/065zsSZ96udsClvYwrOfrXk",
    "bQa8RhhTbtieSC5gCizlrxNNdsBm/A5gpWjYE+gdNts4ZizDKUZCjq0JHtLyXjktoNLC9iUWqRJ",
    "wGtswgBDNvBR9OdG2ODJKi7iGKad+cVGS7ya2xTXIEQmgdI2RhCpAgVO/cuQNqbKBhGi0kk61LD",
    "1DFoM7QT01Mrx+JeQEbexazK5tZSPBDQ3hGBOzhjTJNdC7LwkzJWWO1RjjB92jrzDLuvEi1sbPT",
    "uCABBGEtnJSBm3MszhB2SVWtuSfobZTqud1UIGkSdlIMpjQsehaK/XmCfT5hIsr3pQi9vPOa4Nf",
    "AWDWIJJTPj7HEi7nTRS+nNQSnvfS7O7a5Fg7E83I0PrG58CxGlpdbddAAoyqBscWGQXaB+vTF9j",
    "EcEWVxkI9z0p9Vvds/971rvv3gzX9+92V/v04HwcPHw6edPxBz0jNYCj0AGZpVczfs/N+vDLv2y",
    "X2BWVw3g3cNd/i+sEKvrKG11u5FvluV//8frXAV8W/SiXDna7g3inwHBRwh7nt+C93fvv6h+8f/",
    "fSzfvndRHy4jb9yg7+S/ra4l1W3fddRPr636J+W2Xp6I6HZdx9v8Yv3Cn5hx6qlp0/1SbPR/6L/",
    "DM4araDdOUma2fpskbdakHdx/77t2TCY09wgg1aY79/smJhsX2HnP1mR93CLPW6v+JPn/fpoP/y",
    "7p8V1PNiCP8Zf84Lf7s5//3Q/fMb/bIv8Dwrr/SDt4QfEZmoYbM4IRyXjbZO/u+K8fxj3psj5v1",
    "1evX5l6l11R1zlFdbXvxO3r36udfxNf39T/fAK7x+/xnpsyvcu/dzrptePnlu/9X4+/mz5XaEWU",
    "Rau2dnkj3HzMVr39D/i37872m/RXzas/fIP0F99csYJm+NWJtsq5re70n5HXD6SQNT6/eK/UU/W",
    "9Xfr+qtbhfi2436v+dHJHnXpDw+gHaw=",
    ""
  };

  static char newstr [1533] = "";
  newstr[0] = '\0';
  for (i = 0; i < 22; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c22_ROS_Turtlebot_example(SimStruct *S)
{
  const char* newstr = sf_c22_ROS_Turtlebot_example_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(4077644398U));
  ssSetChecksum1(S,(1068481659U));
  ssSetChecksum2(S,(2960451546U));
  ssSetChecksum3(S,(728722345U));
}

static void mdlRTW_c22_ROS_Turtlebot_example(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c22_ROS_Turtlebot_example(SimStruct *S)
{
  SFc22_ROS_Turtlebot_exampleInstanceStruct *chartInstance;
  chartInstance = (SFc22_ROS_Turtlebot_exampleInstanceStruct *)utMalloc(sizeof
    (SFc22_ROS_Turtlebot_exampleInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc22_ROS_Turtlebot_exampleInstanceStruct));
  chartInstance = new (chartInstance) SFc22_ROS_Turtlebot_exampleInstanceStruct;
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.mdlStart =
    sf_opaque_mdl_start_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c22_ROS_Turtlebot_example;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c22_JITStateAnimation,
    chartInstance->c22_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c22_ROS_Turtlebot_example(chartInstance);
}

void c22_ROS_Turtlebot_example_method_dispatcher(SimStruct *S, int_T method,
  void *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c22_ROS_Turtlebot_example(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c22_ROS_Turtlebot_example(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c22_ROS_Turtlebot_example(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c22_ROS_Turtlebot_example_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
