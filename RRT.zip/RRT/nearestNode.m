function [minIdx,minDist] = nearestNode(tree, q_rand)

[rows, ~] = size(tree);
x0 = q_rand(1); y0 = q_rand(2);
minIdx = 1; 
minDist = sqrt((tree(1,1) - x0)^2 + (tree(1,2) - y0)^2);

for i = 2:rows
    x = tree(i,1); y = tree(i,2);
    distence = sqrt((x-x0)^2 + (y-y0)^2);

    if(distence < minDist) 
        minDist = distence;
        minIdx = i;
    end
end
