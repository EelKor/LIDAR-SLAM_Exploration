function [WP, WP_xy] = pruning(shorestNode, xy)
WP_xy = [xy(shorestNode,1), xy(shorestNode,2)];
WP = shorestNode;
